package test;

import GameManager.*;
import CharacterManager.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Collections;
import java.util.List;

public class HunterTest {

    @Vampiretest
    void testHunterInitializationAndGetters() {
        String name = "Van Helsing";
        int gold = 100;
        int health = 80;
        int power = 50;
        int goodness = 10;

        // Creamos listas vacías para simplificar el test
        List<SpecialAbility> abilities = Collections.emptyList();
        List<Weapon> weapons = Collections.emptyList();
        List<Weapon> activeWeapons = Collections.emptyList();
        List<Armor> armor = Collections.emptyList();
        List<Armor> activeArmor = Collections.emptyList();
        List<Minion> minions = Collections.emptyList();
        List<Modifiers> weaknesses = Collections.emptyList();
        List<Modifiers> strengths = Collections.emptyList();

        Hunter hunter = new Hunter(name, abilities, weapons, activeWeapons, armor, activeArmor, minions,
                gold, health, power, weaknesses, strengths, goodness);

        assertEquals(name, hunter.getName());
        assertEquals(health, hunter.getHealth());
        assertEquals(power, hunter.getPower());
        assertEquals(gold, hunter.getGold());
        assertEquals(goodness, hunter.getGoodness());
        assertEquals(abilities, hunter.getSpecialAbilities());
        assertEquals(weapons, hunter.getWeapons());
        assertEquals(activeWeapons, hunter.getActiveWeapons());
        assertEquals(armor, hunter.getArmor());
        assertEquals(activeArmor, hunter.getActiveArmor());
        assertEquals(minions, hunter.getMinions());
        assertEquals(weaknesses, hunter.getWeaknesses());
        assertEquals(strengths, hunter.getStrengths());
    }
}
