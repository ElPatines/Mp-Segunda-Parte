package test;

import GameManager.*;
import CharacterManager.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class WeaponTest {

    @Test
    public void testConstructorAndGetters() {
        Weapon sword = new Weapon(true, "Greatsword", 50);
        assertTrue(sword.isTwoHands());
        assertEquals("Greatsword", sword.getName());
        assertEquals(50, sword.getDamage());
    }

    @Test
    public void testSetters() {
        Weapon axe = new Weapon(false, "Axe", 30);

        axe.setTwoHands(true);
        axe.setName("Battle Axe");
        axe.setDamage(45);

        assertTrue(axe.isTwoHands());
        assertEquals("Battle Axe", axe.getName());
        assertEquals(45, axe.getDamage());
    }
}
