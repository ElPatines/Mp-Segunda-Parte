package test;

import GameManager.*;
import CharacterManager.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// Mock básico para GameCharacter
class MockVampire extends Vampire {
    private int bloodPoints;
    private String name;

    public MockVampire(String name, int bloodPoints) {
        this.name = name;
        this.bloodPoints = bloodPoints;
    }

    @Override
    public int getBloodPoints() {
        return bloodPoints;
    }

    @Override
    public void setBloodPoints(int points) {
        this.bloodPoints = points;
    }

    @Override
    public String getName() {
        return name;
    }
}

// Otro personaje que no sea vampire
class MockHuman extends GameCharacter {
    @Override
    public String getName() {
        return "Human";
    }
}

public class DisciplineTest {

    private Discipline discipline;

    @BeforeEach
    void setUp() {
        discipline = new Discipline("Celeridad", 5, 3, 10);
    }

    @Test
    void testDisciplineGetters() {
        assertEquals("Celeridad", discipline.getName());
        assertEquals(5, discipline.getAttack());
        assertEquals(3, discipline.getDefense());
        assertEquals(10, discipline.getBloodCost());
    }

    @Test
    void testUseAbilityWithSufficientBlood() {
        MockVampire vampire = new MockVampire("Drácula", 20);
        boolean result = discipline.useAbility(vampire);
        assertTrue(result);
        assertEquals(10, vampire.getBloodPoints());
    }

    @Test
    void testUseAbilityWithInsufficientBlood() {
        MockVampire vampire = new MockVampire("Nosferatu", 5);
        boolean result = discipline.useAbility(vampire);
        assertFalse(result);
        assertEquals(5, vampire.getBloodPoints()); // No cambia
    }

    @Test
    void testUseAbilityWithNonVampire() {
        GameCharacter human = new MockHuman();
        boolean result = discipline.useAbility(human);
        assertFalse(result);
    }
}
