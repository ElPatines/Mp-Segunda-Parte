package CharacterManager;

import org.junit.jupiter.api.Test;
import GameManager.*;
import CharacterManager.*;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

// Clase mock para GameCharacter
class MockGameCharacter extends GameCharacter {
    private List<Modifiers> weaknesses = new ArrayList<>();

    @Override
    public List<Modifiers> getWeaknesses() {
        return weaknesses;
    }

    @Override
    public String toString() {
        return "MockCharacter";
    }
}

// Clase mock para Modifiers
class MockModifier extends Modifiers {
    private final String name;
    private final int value;

    public MockModifier(String name, int value) {
        this.name = name;
        this.value = value;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getValue() {
        return value;
    }
}

public class DecoratorDebilitiesTest {

    @Test
    public void testAddDebilityToCharacter() {
        MockGameCharacter character = new MockGameCharacter();
        MockModifier weakness = new MockModifier("Fuego", 10);

        DecoratorDebilities decorated = new DecoratorDebilities(character, weakness);

        // Verifica que la debilidad fue agregada
        assertTrue(character.getWeaknesses().contains(weakness));
    }

    @Test
    public void testToStringIncludesDebilityInfo() {
        MockGameCharacter character = new MockGameCharacter();
        MockModifier weakness = new MockModifier("Hielo", 5);

        DecoratorDebilities decorated = new DecoratorDebilities(character, weakness);

        String expected = "MockCharacter\nDebilidad añadida: Hielo (Valor: 5)";
        assertEquals(expected, decorated.toString());
    }
}
