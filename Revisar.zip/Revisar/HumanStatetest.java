package CharacterManager;

import GameManager.*;
import CharacterManager.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// Mock básico para Lycanthrope
class MockLycanthrope implements Lycanthrope {
    private int rage = 0;
    private LycanthropeState state;

    @Override
    public int getRage() {
        return rage;
    }

    @Override
    public void incRage() {
        rage++;
    }

    @Override
    public void setState(LycanthropeState newState) {
        this.state = newState;
    }

    @Override
    public LycanthropeState getState() {
        return state;
    }
}

public class HumanStateTest {

    private HumanState humanState;
    private MockLycanthrope lycanthrope;

    @BeforeEach
    void setUp() {
        humanState = new HumanState();
        lycanthrope = new MockLycanthrope();
    }

    @Test
    void testTakeDamageIncrementsRage() {
        humanState.takeDamage(lycanthrope);
        assertEquals(1, lycanthrope.getRage());
    }

    @Test
    void testTakeDamageTriggersTransformation() {
        // Sube la rabia a 4 antes del golpe final
        for (int i = 0; i < 4; i++) {
            lycanthrope.incRage();
        }
        humanState.takeDamage(lycanthrope);
        assertTrue(lycanthrope.getState() instanceof BeastState);
    }

    @Test
    void testAttackPrintsMessage() {
        // Este test puede ser mejorado con captura de salida si deseas
        assertDoesNotThrow(() -> humanState.attack());
    }

    @Test
    void testChangeHeightPrintsMessage() {
        // Este test también se podría mejorar con System.out capture
        assertDoesNotThrow(() -> humanState.changeHeight());
    }
}
