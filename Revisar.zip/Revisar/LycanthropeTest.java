package test;

import GameManager.*;
import CharacterManager.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Collections;

public class LycanthropeTest {

    private Lycanthrope lycanthrope;

    @BeforeEach
    public void setUp() {
        lycanthrope = new Lycanthrope(
                "Fenrir", 30, 180,
                Collections.emptyList(), // SpecialAbilities
                Collections.emptyList(), // PrimaryWeapons
                Collections.emptyList(), // SecondaryWeapons
                Collections.emptyList(), // PrimaryArmors
                Collections.emptyList(), // SecondaryArmors
                Collections.emptyList(), // Minions
                100, 20, 10,
                Collections.emptyList(), // Weaknesses
                Collections.emptyList() // Strengths
        );
    }

    @Test
    public void testInitialState() {
        assertEquals(0, lycanthrope.getRage());
        assertEquals(30, lycanthrope.getAge());
        assertEquals(180, lycanthrope.getHeight());
        assertEquals(20, lycanthrope.calcDamage()); // HumanState by default
    }

    @Test
    public void testIncRage() {
        lycanthrope.incRage();
        assertEquals(1, lycanthrope.getRage());
    }

    @Test
    public void testChangeHeight() {
        lycanthrope.setHeight(200);
        assertEquals(200, lycanthrope.getHeight());
    }

    @Test
    public void testStateChangeToBeast() {
        lycanthrope.setState(new BeastState());
        assertEquals(50, lycanthrope.calcDamage()); // Damage should increase
    }
}
