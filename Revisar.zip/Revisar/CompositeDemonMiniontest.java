package test;

import GameManager.*;
import CharacterManager.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CompositeDemonMinionTest {

    private CompositeDemonMinion demon;

    @BeforeEach
    void setUp() {
        demon = new CompositeDemonMinion("Azazel", 100, "Blood Pact");
    }

    @Test
    void testGetName() {
        assertEquals("Azazel", demon.getName());
    }

    @Test
    void testGetHealth() {
        assertEquals(100, demon.getHealth());
    }

    @Test
    void testGetPact() {
        assertEquals("Blood Pact", demon.getPact());
    }

    @Test
    void testSubtractMinionLife() {
        demon.subtractMinionLife(20);
        assertEquals(80, demon.getHealth());
    }

    @Test
    void testSetHealth() {
        demon.setHealth(50);
        assertEquals(50, demon.getHealth());
    }

    @Test
    void testAddMinion() {
        Minion subMinion = new CompositeDemonMinion("Imp", 30, "Fire Pact");
        demon.newMinion(subMinion);
        // No método getMinions(), no se puede verificar que fue agregado
        // Deberías agregar un método como getMinions() en CompositeDemonMinion
    }
}
