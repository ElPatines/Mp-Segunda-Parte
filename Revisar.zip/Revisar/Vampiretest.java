package test;

import GameManager.*;
import CharacterManager.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;

public class VampireTest {

    private Vampire vampire;

    @BeforeEach
    public void setUp() {
        vampire = new Vampire(
                "Dracula",
                Collections.emptyList(), // SpecialAbilities
                Collections.emptyList(), // Weapons
                Collections.emptyList(), // ActiveWeapons
                Collections.emptyList(), // Armor
                Collections.emptyList(), // ActiveArmor
                Collections.emptyList(), // Minions
                100, 50, 25, // gold, health, power
                Collections.emptyList(), // Weaknesses
                Collections.emptyList(), // Strengths
                10, // bloodPoints
                300 // age
        );
    }

    @Test
    public void testInitialValues() {
        assertEquals(10, vampire.getBloodPoints());
        assertEquals(300, vampire.getAge());
        assertEquals(50, vampire.getHealth());
    }

    @Test
    public void testSetBloodPoints() {
        vampire.setBloodPoints(30);
        assertEquals(30, vampire.getBloodPoints());
    }

    @Test
    public void testSetAge() {
        vampire.setAge(350);
        assertEquals(350, vampire.getAge());
    }

    @Test
    public void testDrinkBlood() {
        vampire.drinkBlood(15);
        assertEquals(25, vampire.getBloodPoints());
    }

    @Test
    public void testSubtractCharacterLife() {
        int initialHealth = vampire.getHealth();
        vampire.subtractCharacterLife();
        assertEquals(initialHealth - 1, vampire.getHealth());
    }

    @Test
    public void testSubtractCharacterLifeWhenZero() {
        vampire.setHealth(0);
        vampire.subtractCharacterLife();
        assertEquals(0, vampire.getHealth()); // Should not go negative
    }
}
